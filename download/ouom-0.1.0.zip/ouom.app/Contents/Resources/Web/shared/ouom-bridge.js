/* ouomBridge SDK v1 — 由 WKWebView 在 documentStart 注入 page content world。
 * Web → Native: window.webkit.messageHandlers.ouomBridge.postMessage(JSON 字符串)
 * Native → Web: window.ouom._emit({...})
 * 所有外部网络请求都由原生桥发起，Web 端不直接 fetch（CSP connect-src 'none'）。
 */
(function () {
  'use strict';
  if (window.ouom) return;

  var PROTOCOL = 1;
  var seq = 0;
  var pending = new Map();
  var listeners = new Map();
  var cachedTabId = null;

  function messageHandler() {
    return window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.ouomBridge;
  }

  function invoke(namespace, method, payload, opts) {
    payload = payload || {};
    opts = opts || {};
    return new Promise(function (resolve, reject) {
      var handler = messageHandler();
      if (!handler) {
        reject(new Error('ouomBridge 不可用：请在 ouom 浏览器中打开此页面'));
        return;
      }
      var id = 'r' + (++seq) + '-' + Date.now().toString(36);
      var timeout = opts.timeout || 30000;
      var timer = setTimeout(function () {
        pending.delete(id);
        reject(new Error('调用超时 ' + namespace + '.' + method));
      }, timeout);
      pending.set(id, { resolve: resolve, reject: reject, timer: timer });

      var envelope = { v: PROTOCOL, id: id, type: 'request', namespace: namespace, method: method, payload: payload };
      var sent;
      try {
        sent = handler.postMessage(JSON.stringify(envelope));
      } catch (e) {
        clearTimeout(timer);
        pending.delete(id);
        reject(e);
        return;
      }
      Promise.resolve(sent).then(function (reply) {
        var entry = pending.get(id);
        if (!entry) return;
        clearTimeout(entry.timer);
        pending.delete(id);
        var r = reply;
        if (typeof reply === 'string') {
          try { r = JSON.parse(reply); } catch (e) { reject(new Error('响应不是合法 JSON')); return; }
        }
        if (r && r.ok) resolve(r.result);
        else reject(new Error(r && r.error ? r.error.message : '桥调用失败'));
      }).catch(function (err) {
        var entry = pending.get(id);
        if (!entry) return;
        clearTimeout(entry.timer);
        pending.delete(id);
        reject(err instanceof Error ? err : new Error(String(err)));
      });
    });
  }

  function on(event, fn) {
    if (!listeners.has(event)) listeners.set(event, []);
    listeners.get(event).push(fn);
    return function () { off(event, fn); };
  }
  function off(event, fn) {
    if (!listeners.has(event)) return;
    listeners.set(event, listeners.get(event).filter(function (f) { return f !== fn; }));
  }
  function emit(envelope) {
    if (!envelope || !envelope.event) return;
    (listeners.get(envelope.event) || []).slice().forEach(function (fn) {
      try { fn(envelope.payload, envelope.event); } catch (e) { console.warn('[ouom] listener error', e); }
    });
  }

  async function tabId() {
    if (cachedTabId) return cachedTabId;
    var info = await invoke('system', 'ping');
    cachedTabId = info.tabId;
    return cachedTabId;
  }

  var api = {
    version: PROTOCOL,
    invoke: invoke,
    on: on,
    off: off,
    _emit: emit,
    tabId: tabId,

    /* 命名空间快捷方法 */
    system: {
      ping: function () { return invoke('system', 'ping'); },
      getInfo: function () { return invoke('system', 'getInfo'); },
      readClipboard: function () { return invoke('system', 'clipboard.readText'); },
      writeClipboard: function (text) { return invoke('system', 'clipboard.writeText', { text: text }); },
      openFile: function () { return invoke('system', 'openFile'); },
      saveFile: function (name, text) { return invoke('system', 'saveFile', { name: name, text: text }); },
      dashboard: function () { return invoke('system', 'dashboard'); }
    },
    browser: {
      tabs: function () { return invoke('browser', 'getTabs'); },
      activeTab: function () { return invoke('browser', 'getActiveTab'); },
      open: function (url, kind) { return invoke('browser', 'openTab', { url: url, kind: kind }); },
      navigate: async function (url) {
        var id = await tabId();
        return invoke('browser', 'navigate', { tabId: id, url: url });
      },
      pageContent: function (id) { return invoke('browser', 'getPageContent', id ? { tabId: id } : {}); }
    },
    ai: {
      chat: function (text, sessionId, allowRemote) {
        return invoke('ai', 'chat', { text: text, sessionId: sessionId, allowRemote: allowRemote !== false });
      },
      summarize: function (opts) { return invoke('ai', 'summarize', opts || {}); },
      write: function (opts) { return invoke('ai', 'write', opts || {}); },
      sessions: function () { return invoke('ai', 'sessions.list'); },
      createSession: function (title) { return invoke('ai', 'sessions.create', { title: title || '新对话' }); },
      backends: function () { return invoke('ai', 'backends.list'); }
    },
    doc: {
      list: function () { return invoke('office', 'doc.list'); },
      create: function (title, kind) { return invoke('office', 'doc.create', { title: title || '未命名文档', kind: kind || 'doc' }); },
      get: function (id) { return invoke('office', 'doc.getDocument', { docId: id }); },
      text: function (id) { return invoke('office', 'doc.getText', { docId: id }); },
      setContent: function (id, blocks) { return invoke('office', 'doc.setContent', { docId: id, blocks: blocks }); },
      insert: function (id, text, at) { return invoke('office', 'doc.insertText', { docId: id, text: text, at: at || 'end' }); },
      export: function (id, format) { return invoke('office', 'doc.export', { docId: id, format: format || 'md' }); }
    },
    sheet: {
      get: function (id) { return invoke('office', 'sheet.getTable', { docId: id }); },
      set: function (id, data) { return invoke('office', 'sheet.setTable', { docId: id, data: data }); }
    },
    slide: {
      get: function (id) { return invoke('office', 'slide.getDeck', { docId: id }); },
      set: function (id, data) { return invoke('office', 'slide.setDeck', { docId: id, data: data }); }
    },
    pdf: {
      get: function (id) { return invoke('office', 'pdf.annotations', { docId: id }); },
      set: function (id, data) { return invoke('office', 'pdf.setAnnotations', { docId: id, data: data }); }
    },
    account: {
      user: function () { return invoke('account', 'getUser'); },
      sync: function () { return invoke('account', 'requestSync'); },
      setKey: function (value, account) { return invoke('account', 'setKey', { value: value, account: account || 'openai.apiKey' }); }
    },
    plugin: {
      capabilities: function () { return invoke('plugin', 'capabilities'); }
    },
    ml: {
      stats: function () { return invoke('ml', 'stats'); },
      intent: function (text) { return invoke('ml', 'intent', { text: text }); },
      answer: function (question, limit) { return invoke('ml', 'answer', { question: question, limit: limit || 3 }); },
      summarize: function (text, count) { return invoke('ml', 'summarize', { text: text, sentenceCount: count || 4 }); },
      write: function (text, action, instruction) {
        return invoke('ml', 'write', { text: text, action: action || 'polish', instruction: instruction || '' });
      },
      train: function (text, intent) { return invoke('ml', 'train', { text: text, intent: intent }); },
      corpus: function (documents) { return invoke('ml', 'corpus', { documents: documents }); }
    },
    study: {
      prompt: function () { return invoke('study', 'prompt'); },
      preview: function (text) { return invoke('study', 'preview', { text: text }); },
      importText: function (text) { return invoke('study', 'import', { text: text }); },
      problems: function (query) { return invoke('study', 'problems', { query: query || {} }); },
      update: function (problem) { return invoke('study', 'update', { problem: problem }); },
      remove: function (id) { return invoke('study', 'delete', { id: id }); },
      merge: function () { return invoke('study', 'merge'); },
      retag: function () { return invoke('study', 'retag'); },
      analyze: function () { return invoke('study', 'analyze'); },
      outline: function () { return invoke('study', 'outline'); },
      customize: function (spec) { return invoke('study', 'customize', { spec: spec }); },
      plans: function () { return invoke('study', 'plans'); },
      due: function (limit) { return invoke('study', 'due', { limit: limit || 20 }); },
      submit: function (id, correct) { return invoke('study', 'submit', { problemId: id, correct: correct }); },
      profile: function () { return invoke('study', 'profile'); },
      saveProfile: function (profile) { return invoke('study', 'profile.update', { profile: profile }); },
      export: function () { return invoke('study', 'export'); },
      clear: function () { return invoke('study', 'clear'); },
      ask: function (question) { return invoke('study', 'ask', { question: question }); }
    }
  };

  window.ouom = api;
  window.dispatchEvent(new CustomEvent('ouom:ready'));
})();
