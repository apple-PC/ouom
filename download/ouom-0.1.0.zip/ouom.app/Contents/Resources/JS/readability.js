/* 轻量正文抽取：优先 article/main，剔除导航与脚本，返回结构化 JSON 字符串。
 * Phase 2 可替换为 Mozilla Readability；接口 window.__ouomReadability() 不变。
 */
window.__ouomReadability = function () {
  function pick() {
    var candidates = ['article', 'main', '[role="main"]', '.post-content', '.article-content', '#content'];
    for (var i = 0; i < candidates.length; i++) {
      var node = document.querySelector(candidates[i]);
      if (node && (node.innerText || '').trim().length > 120) return node;
    }
    var best = document.body, bestLen = 0;
    var blocks = document.querySelectorAll('div, section');
    for (var j = 0; j < blocks.length; j++) {
      var text = (blocks[j].innerText || '').trim();
      var links = blocks[j].querySelectorAll('a').length;
      var score = text.length - links * 40;
      if (score > bestLen) { bestLen = score; best = blocks[j]; }
    }
    return best || document.body;
  }

  function clean(root) {
    var clone = root.cloneNode(true);
    var drop = clone.querySelectorAll('script, style, nav, header, footer, aside, form, iframe, noscript, svg, .advert, .ads');
    for (var i = 0; i < drop.length; i++) drop[i].parentNode && drop[i].parentNode.removeChild(drop[i]);
    return (clone.innerText || clone.textContent || '')
      .replace(/\r/g, '')
      .replace(/[ \t]+/g, ' ')
      .replace(/\n{3,}/g, '\n\n')
      .trim();
  }

  var root = pick();
  var text = clean(root);
  if (text.length > 20000) text = text.slice(0, 20000);
  var bylineEl = document.querySelector('[rel="author"], .author, .byline');
  var desc = document.querySelector('meta[name="description"]');
  return JSON.stringify({
    title: document.title || '',
    text: text,
    byline: bylineEl ? (bylineEl.innerText || '').trim() : '',
    excerpt: (desc && desc.content) ? desc.content : text.slice(0, 200)
  });
};
